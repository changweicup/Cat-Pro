import React from 'react'
import { Button } from "antd"

export default class HomeIndex extends React.Component {
    render(){
        return (
            <div>
                <p>HomeIndex</p>
                <Button type="primary">hello world</Button>
            </div>
        )
    }
}

