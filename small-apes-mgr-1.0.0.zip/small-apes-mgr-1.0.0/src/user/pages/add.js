import React from 'react'

class AddUserPage extends React.Component {
    render(){
        return (
            <div>
                <p>AddUserPage</p>
            </div>
        )
    }
}

export default AddUserPage;

