import React from 'react'

export default class AddBlogPage extends React.Component {
    render(){
        return (
            <div>
                <p>AddBlogPage</p>
            </div>
        )
    }
}

