import React from 'react'

export default class BlogListPage extends React.Component {
    render(){
        return (
            <div>
                <p>BlogListPage</p>
            </div>
        )
    }
}

